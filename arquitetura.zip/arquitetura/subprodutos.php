<span>
    <img src='basca.jpg' width='200px' ><br>
    Torra Escura- R$5,00/Kg<br>
    Torra Média - R$10,00/Kg<br>
    Torra Clara - R$25,00/Kg<br><br>
</span>

<span>
    <img src='cafe.jpg' width='200px'> <br>
    copo de 500 ml <br>
    Espresso - R$5,00<br>
    Americano - R$3,00<br>
    Cappuccino - R$3,50<br>
</span>

<span>
    <img src='cafe2.jpg' width='200px '> <br>
    copo de 800 ml <br>
    Espresso - R$7,00<br>
    Americano - R$5,00<br>
    Cappuccino - R$8,50<br>
</span>

<span>
    <img src='cafe3.jpg' width='200px'> <br>
    copo de 500 ml <br>
    Espresso - R$5,00<br>
    Americano - R$3,00<br>
    Cappuccino - R$3,50<br>
</span>

<span>
    <img src='cafe4.jpg' width='200px'> <br>
    copo de 800 ml <br>
    Espresso - R$5,00<br>
    Americano - R$3,00<br>
    Cappuccino - R$3,50<br>
</span>