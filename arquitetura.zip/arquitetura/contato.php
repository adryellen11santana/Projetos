<div id='contato'>
    <h1>Contato</h1>
    E-mail:contato@cafeespetacular.com.br<br>
    Telefone:5555-5555
</div>