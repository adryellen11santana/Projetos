<div id="Ofertas">
    <h1>Ofertas</h1>

        <span>
            <img src='pula.jpg' width='200px'> <br>
			No aluguel da cama elastica com o escorregador inflável: <br>
			-> Ganhe 10% de desconto!!! <br><br>

        </span>

        <span>
            <img src='oferta2.jpg' width='200px'> <br>
            Espresso de 150ml + pão de queijo (pequeno) - R$ 2,99
            Espresso de 200ml + pão de queijo (médio) - R$ 3,99
            Espresso de 215ml + pão de queijo (grande) - R$ 5,99
        </span>
</div>