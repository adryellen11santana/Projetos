     <div id='sobre'>
        <h1>Sobre</h1>
		<hr>
        <h2>Criação</h2>
        Inspirada principalmente na nossa criança interior...
        <h2>Objetivo</h2>
        Nosso maior objetivo é levar alegria para todas as festas!
        <h2>Visão</h2>
        Nós da Driany Toys visamos um mundo de festas muito mais alegres, independente da sua idade!
    </div>