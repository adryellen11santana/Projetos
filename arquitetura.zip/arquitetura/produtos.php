    <div id='produtos'>
        <h1 onclick="abreSubMenu('divSubMenuProdutos');">Produtos</h1>
        <div id='divSubMenuProdutos'></div>
        <h1 onclick="abreSubMenu('divSubMenuPedidos');">Pedido</h1>
        <div id='divSubMenuPedidos'></div>
    </div>