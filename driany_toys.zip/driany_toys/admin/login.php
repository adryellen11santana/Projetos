<div id="divTitulo">Login<span id='spanTitulo'></span></div>		
<div id="divConteudo">
	<form id='frmLogin' action="javascript:autenticar();" onSubmit="return validaLogin();">
		Usuário<input type='text' name='usuario' id='usuario'><br>
		Senha<input type='password' name='senha' id='senha'><br>
		<input type='submit' value='login'>
	</form>
</div>