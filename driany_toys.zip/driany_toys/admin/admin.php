<div id="divTitulo">Área Administrativa</div>
<div id="divMenu">
	<a href="javascript:abre('frmConsultaPedidos','divConteudo');">  Consulta Pedidos</a> |
    <a href="javascript:abre('frmConsultaNovidades','divConteudo');"> Consulta Novidades </a> |
	<a href="javascript:abre('frmIncNovidades','divConteudo');"> Incluir Novidades </a> |
	<a href="javascript:sair();"> Sair </a>
</div> <br>
<div id="divConteudo"></div>		
<script language='javascript'>
	abre('frmConsultaPedidos','divConteudo');
</script>