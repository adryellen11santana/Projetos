<?php
	if ($email == "")
		$sql = "select id, email, pedido from pedidos order by id desc";
	else
		$sql = "select id, email, pedido from pedidos
		where email like ('%".$db->real_escape_string($email)."%') order by id desc";

	if($result=$db->query($sql)){
		while($linha=$result->fetch_array()){$res[]=$linha;}
		echo "
			<br><center>
			  	<table border='1' width='100%'>
			  		<tr><th width='10%'>id</th><th width='15%'>e-mail</th><th width='75%'>pedido</th></tr>
			  	</table>
			<center><br>";
		foreach($res as $memo){
			echo "
			<table border='1' width='100%'>
				<tr>
					<td width='10%'>{$memo[0]}</td>
					<td width='15%'>{$memo[1]}</td>
					<td width='75%'><pre>{$memo[2]}</pre></td>
				</tr>
				<tr>
					<td colspan='3'><center><a href='javascript:excluirPedido({$memo[0]})'>Excluir</a> - <a href='javascript:carregarPedido({$memo[0]})'>Alterar</a></center></td>
				</tr>
			</table>
			<center><br>";
		}
	}
	else{
		echo "Erro na consulta";
	}
?>