<?php
	if(isset($id)){
		$sql = "select id, titulo, conteudo from novidades
				where id = $id";

		if($result=$db->query($sql)){
			$novidade=$result->fetch_array()
			?>
			
			<form name='frmAltNovidade' id='frmAltNovidade'  method='POST' action="javascript:alterarNovidade(<?php echo $novidade[0] ?>);" onSubmit="return validaNovidade();" >
				<fieldset><legend>Novidade</legend>
					Titulo: <input type='text' name='txtTitulo' id='txtTitulo' size='10' value='<?php echo $novidade[1] ?>'><br><br>
					Conteudo: <br>
					<textarea name='txtConteudo' id='txtConteudo' cols='90' rows='15' ><?php echo $novidade[2] ?></textarea>
					<fieldset>
						<input type='submit' name='grv' id='grv' value='enviar'><input type='reset' name='lmp' id='lmp' value='limpar'>
					</fieldset>
				</fieldset>	
			</form>
			<?php
		}
	}
?>