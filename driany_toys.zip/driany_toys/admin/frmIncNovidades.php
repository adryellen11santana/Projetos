<form name='frmIncNovidade' id='frmIncNovidade'  method='POST' action="javascript:gravaNovidade();"  onSubmit="return validaNovidade();" >
<fieldset><legend>Novidade</legend>
    Titulo: <input type='text' name='txtTitulo' id='txtTitulo' size='10'> <br> <br>
    Conteúdo: <br>
    <textarea name='txtConteudo' id='txtConteudo' cols='90' rows='15'></textarea>
    </fieldset>
    <fieldset>
        <input type='submit' name='grv' id='grv' value='enviar'><input type='reset' name='lmp' id='lmp' value='limpar'>
    </fieldset>
</form>