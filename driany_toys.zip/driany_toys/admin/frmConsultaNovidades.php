<form name='frmConsultaNovidades' id='frmConsultaNovidades' method='POST' action="javascript:consultarNovidade();" >
	<fieldset><legend>Consulta Novidades</legend>
		titulo:<input type='text' name='titulo' id='titulo' size='10'><br>
	</fieldset>
	<fieldset>
		<input type='submit' name='con' value='consultar'>
		<input type='reset' name='lmp' value='limpar'>
	</fieldset>
</form>
<div id='resultadoConsulta'></div>