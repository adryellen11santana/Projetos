<?php
	session_destroy();
?>