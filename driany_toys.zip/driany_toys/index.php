<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="stylesheet" type="text/css" href="css.css">
		<script language='javascript' src='biblio.js'></script>
	</head>
	<body>
		<div id="divTitulo">
		<img src='jare.jpg'> Driany Toys <span id='spanTitulo'> </span>
		<div id='divAdmin'><a href='admin/'>Área Administrativa</a></div>
	</div>
		<div id="divMenu"><ul>
	<li><a href="javascript:abreMenu('Sobre');">Sobre</a></li>
	<li><a href="javascript:abreMenu('Produtos');">Produtos</a>
		<ul id='subMenuProdutos'>
		<li><a href="javascript:abreSubMenu('divSubMenuProdutos');">Produtos</a></li>
		<li><a href="javascript:abreSubMenu('divSubMenuPedidos');">Pedidos</a></li>
	</ul>
</li>
	<li><a href="javascript:abreMenu('Ofertas');">Ofertas</a></li>
	<li><a href="javascript:abreMenu('Novidades');">Novidades</a></li>
	<li><a href="javascript:abreMenu('Contato');">Contato</a></li>
</ul>

</div>
		<div id="divConteudo"></div>
		<div id="divRodape"><span id='telefone'>4002-8922</span><span id='email'> drianytoys@aluguel.com </span></div>
        <script language='javascript'>
			abre('Sobre','divConteudo');
		</script>
		
	</body>
</html>
