<html>
	<head>
		<script language='javascript' src='biblio.js'></script>
	</head>
	<body>
		<div id='menu'><a href="javascript:abrePagina('exemplo.php?texto=Titulo','conteudo')">exemplo1 com GET</a>-<a href="javascript:abre(1,'conteudo');">pagina com itens</a>-<a href="javascript:abre(2,'conteudo');">segundo item</a></div>
		<div id='conteudo'></div>
	</body>
</html>
