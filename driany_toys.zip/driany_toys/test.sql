-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.25a
-- Versão do PHP: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `test`
--

DELIMITER $$
--
-- Procedimentos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `test_multi_sets`()
    DETERMINISTIC
begin
        select user() as first_col;
        select user() as first_col, now() as second_col;
        select user() as first_col, now() as second_col, now() as third_col;
        end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `demetrio`
--

CREATE TABLE IF NOT EXISTS `demetrio` (
  `teste` int(11) NOT NULL,
  `teste1` varchar(45) DEFAULT NULL,
  `teste2` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`teste`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `demetrio`
--

INSERT INTO `demetrio` (`teste`, `teste1`, `teste2`) VALUES
(1, 'dado1', 'dado2'),
(2, 'dado4', 'dado5');

-- --------------------------------------------------------

--
-- Estrutura da tabela `novidades`
--

CREATE TABLE IF NOT EXISTS `novidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `conteudo` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `novidades`
--

INSERT INTO `novidades` (`id`, `titulo`, `conteudo`) VALUES
(1, 'sorvete de cafe', 'sorvete de cafe nao eh bom nao recomendo'),
(2, 'manga de cafe', 'manga de cafe eh uma abonimacao da ciencia tem que catar o que que fez isso na porrada'),
(3, 'feijoada de cafe', 'supimpa dms brohter');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos`
--

CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `pedido` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `email`, `pedido`) VALUES
(2, 'a@b', 'sorvete de cafeh'),
(3, 'b@c', 'manga de cafe'),
(4, 'a@b', 'feijoada de cafe'),
(5, 'a@b', 'um livro de cafÃ©');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
