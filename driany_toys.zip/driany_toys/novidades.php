<?php
    header("Content-type: text/html; charset=utf-8");
    $sql = "select titulo, conteudo from novidades";
	if($result=$db->query($sql)){
		while($linha=$result->fetch_array()){$res[]=$linha;}
		foreach($res as $novi){
			echo "
            <center>
                <table border='1' width='80%'>
                    <tr><td><center><h2>{$novi[0]}<h2></center></td></tr>
                    <tr><td>{$novi[1]}</td></tr>
                </table>
            </center>
            <br>"
            ;
		}
	}
	else{
		echo "Erro na consulta";
	}
?>