<span>
    <img src='basca.jpg' width='200px' height='200px' ><br>
	Basquete dos Minions <br>
	Aluguel-> R$ 65,00 <br><br>
</span>

<span>
    <img src='lab.jpg' width='200px' height='200px'> <br>
    Labirinto Inflavel<br>
	Aluguel-> R$95,00 <br><br>
</span>

<span>
    <img src='escalada.jpg' width='200px' height='200px'> <br>
    Escalada Inflavel <br>
	Aluguel-> R$100,00 <br><br>
</span>

<span>
    <img src='escorregador.jpg' width='200px' height='200px'> <br>
	Escorregador Inflavel <br>
    Aluguel-> R$100,00 <br><br>
</span>

<span>
    <img src='pula.jpg' width='200px' height='200px'> <br>
	Cama Elastica <br>
    Aluguel-> R$200,00 <br><br>
</span>