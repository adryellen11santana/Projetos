     <div id='contato'>
    <h1>Contato</h1>
	<hr> <br>
    E-mail:drianytoys@aluguel.com<br>
    Telefone:4002-8922

    </div>