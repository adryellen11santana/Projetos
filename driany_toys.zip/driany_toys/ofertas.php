<div id="Ofertas">
    <h1>Ofertas</h1>
	<hr> <br>
        <span>
            <img src='pula.jpg' width='200px' height='200px'> <br>
			No aluguel da cama elastica <br> com o escorregador inflável: <br>
			-> Ganhe 10% de desconto!!! <br><br>

        </span>

        <span>
            <img src='basca.jpg' width='200px' height='200px'> <br>
            No aluguel do basquete dos minions com a escalada: <br>
			-> Ganhe 15% de desconto!!! <br><br>
        </span>
</div>