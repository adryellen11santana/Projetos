package com.stackmobile.teste2.view.cliente

data class Ordem_Cliente(
    val Servico:String?=null,
    val Status:String?=null,
    val Valor:String?=null,
    val Telefone:String?=null
)
