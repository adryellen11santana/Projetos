package com.stackmobile.teste2.view.Relatorios

data class Ordem_Relatorio(
    val Servico:String?=null,
    val Status:String?=null,
    val Valor:String?=null,
)
