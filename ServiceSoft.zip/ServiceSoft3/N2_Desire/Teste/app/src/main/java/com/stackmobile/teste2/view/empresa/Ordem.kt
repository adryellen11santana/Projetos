package com.stackmobile.teste2.view.empresa

data class Ordem(
    val Email:String?=null,
    val Nome:String?=null,
    val Servico:String?=null,
    val Telefone:String?=null,
    val Status:String?=null,
)
